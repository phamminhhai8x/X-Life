ALTER TABLE `#__categoryblock` ADD COLUMN `customblocklayouttop` text NOT NULL;
ALTER TABLE `#__categoryblock` ADD COLUMN `customblocklayoutbottom` text NOT NULL;

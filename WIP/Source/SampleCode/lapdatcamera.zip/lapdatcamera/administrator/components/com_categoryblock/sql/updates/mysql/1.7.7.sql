ALTER TABLE `#__categoryblock` ADD COLUMN   `storethumbnails` smallint(6) NOT NULL;
ALTER TABLE `#__categoryblock` ADD COLUMN   `thumbnailspath` varchar(255) NOT NULL;
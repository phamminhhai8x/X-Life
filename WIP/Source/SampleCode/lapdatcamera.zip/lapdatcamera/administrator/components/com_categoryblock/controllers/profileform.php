<?php
/**
 * CategoryBlock Joomla! 2.5 Native Component
 * @version 1.8.0
 * @author DesignCompass corp <support@joomlaboat.com>
 * @link http://www.joomlaboat.com
 * @GNU General Public License
 **/



// No direct access to this file
defined('_JEXEC') or die('Restricted access');
 
// import Joomla controllerform library
jimport('joomla.application.component.controllerform');
 
/**
 * CategoryBlock - ProfileForm Controller
 */
class CategoryBlockControllerProfileForm extends JControllerForm
{
    
	function save()
	{
		$task = JRequest::getVar( 'task');
		
		// get our model
		$model = $this->getModel('ProfileForm');
		// attempt to store, update user accordingly
		
		if($task != 'save' and $task != 'apply')
		{
			$msg = JText::_( 'COM_CATEGORYBLOCK_ITEM_WAS_UNABLE_TO_SAVE');
			$this->setRedirect($link, $msg, 'error');
		}
		
		
		if ($model->store())
		{
		
			if($task == 'save')
				$link 	= 'index.php?option=com_CategoryBlock&controller=profilelist';
			elseif($task == 'apply')
			{
	
				
				$link 	= 'index.php?option=com_CategoryBlock&view=profileform&layout=edit&id='.$model->id;
			}
			
			$msg = JText::_( 'COM_CATEGORYBLOCK_ITEM_SAVED_SUCCESSFULLY' );
			
			$this->setRedirect($link, $msg);
		}
		else
		{
			
			$msg = JText::_( 'COM_CATEGORYBLOCK_ITEM_WAS_UNABLE_TO_SAVE');
			$this->setRedirect($link, $msg, 'error');
		}
			
	}
	
	/**
	* Cancels an edit operation
	*/
	function cancelItem()
	{
		

		$model = $this->getModel('item');
		$model->checkin();

		$this->setRedirect( 'index.php?option=com_CategoryBlock&controller=profilelist');
	}

	/**
	* Cancels an edit operation
	*/
	function cancel()
	{
		$this->setRedirect( 'index.php?option=com_CategoryBlock&controller=profilelist');
	}

	/**
	* Form for copying item(s) to a specific option
	*/
}

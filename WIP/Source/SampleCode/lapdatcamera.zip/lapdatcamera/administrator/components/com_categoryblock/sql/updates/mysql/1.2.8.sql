ALTER TABLE `#__categoryblock` ADD COLUMN `showfeaturedonly` tinyint(1) NOT NULL;

ALTER TABLE `#__categoryblock` ADD COLUMN `recursive` tinyint(1) NOT NULL;
ALTER TABLE `#__categoryblock` ADD COLUMN `randomize` tinyint(1) NOT NULL;
<?php
/**
 * CategoryBlock Joomla! 2.5 Native Component
 * @version 1.8.0
 * @author DesignCompass corp <support@joomlaboat.com>
 * @link http://www.joomlaboat.com
 * @GNU General Public License
 **/



// No direct access to this file
defined('_JEXEC') or die('Restricted Access');
?>
<tr>
        <td colspan="3"><?php echo $this->pagination->getListFooter(); ?></td>
</tr>
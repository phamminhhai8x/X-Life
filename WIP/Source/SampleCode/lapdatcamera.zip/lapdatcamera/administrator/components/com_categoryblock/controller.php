<?php
/**
 * CategoryBlock Joomla! 2.5 Native Component
 * @version 1.8.0
 * @author DesignCompass corp <support@joomlaboat.com>
 * @link http://www.joomlaboat.com
 * @GNU General Public License
 **/


// No direct access to this file
defined('_JEXEC') or die('Restricted access');
 
// import Joomla controller library
jimport('joomla.application.component.controller');
 
/**
 * General Controller of CategoryBlock component
 */
class CategoryBlockController extends JController
{
        /**
         * display task
         *
         * @return void
         */
        function display($cachable = false) 
        {
                
                // set default view if not set
                JRequest::setVar('view', JRequest::getCmd('view', 'profilelist'));
                
                
                // call parent behavior
                parent::display($cachable);
        }
}

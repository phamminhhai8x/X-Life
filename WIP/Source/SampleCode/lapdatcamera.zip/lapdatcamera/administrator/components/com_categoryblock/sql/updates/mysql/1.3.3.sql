ALTER TABLE `#__categoryblock` ADD COLUMN `titleimagepos` varchar(20) NOT NULL;
ALTER TABLE `#__categoryblock` ADD COLUMN `orientation` tinyint(1) NOT NULL;